var spectrum = (function () {
	var m_specrumTimeSlices=[];
	var m_colorTimeSlices=[];
	var m_arrSpecrumTimeSlices=[];
	var m_slices;
	var m_width;
	var m_count=[];
	var m_maxval=4;
	var graphData = [400, 800, 300, 400, 600, 900, 500, 900, 100];
	var graphLabels = [1, 2, 3, 4, 5, 6, 7, 8, 9];
	var empty;
	var leftGraphMargin=40;
	var rightGraphMargin=30;
	var thisModule = {};
	thisModule.m_transmit=false;
	thisModule.m_power=50;
	var scaleFactor=0.5;
	var scaleOffset=4;
	var socket = [];
	var connectedNodes = [];
        // var Ayat_div = '';
	//document.getElementById("dis_canvas").innerHTML = '';
	//var Ayat_context = '';
       // var Ayat_img = new Image();
	//thisModule.Ayat_img = Ayat_img;
	/*var sock;
	var sock = io.connect('128.173.221.40:8888', {'force new connection': true});
	for (var i =0;i<48;i++) {
		socket[i] = sock;
	}*/
	
	//in MHZ
	var centerF_=751;
	thisModule.bandwidth_=12;
	thisModule.lowBound_=centerF_-thisModule.bandwidth_/2;
	thisModule.selectedCenter=0;
	thisModule.selectedBandWidth=0;
	var highBound_=centerF_+thisModule.bandwidth_/2;
	var period;
	var r;
	var m_showStatus;

	// overlay is layer211, layer212 and so on...
	function processResponse(data, elevGridID, elevGridColorID, heatmapDiv, line_graphID, overlay, canvasID, displacement_canvas, displacement_canvas_color, lastDigitsIP) {
		var data = data.map(function(x) { return Math.log(x)*scaleFactor + scaleOffset; });
		
		if (thisModule.rand){
			data=[];
			for(var i=0; i<50; i++) {
				data.push(3*Math.random());
			}
			console.log(data);
		} else {
			if(data.length<2){
				//m_showfloors();
				m_showStatus('<span style="color:red;">Spectral data not available.  Please try a different node or turn on random mode.</span>');
				return;
			}
		}

		//Graph
		graphLabels=[];
		var nticks=2;
		for(var i=0; i<=nticks; i++) {
			graphLabels.push(Math.round((thisModule.lowBound_+(i)*thisModule.bandwidth_/(nticks))*1000000)/1000000);
		}
		makeGraph(canvasID, data, graphLabels);
		var elevGrid;
		elevGrid=document.getElementById(elevGridID);
		var colorGrid=document.getElementById(elevGridColorID);
		//alert(colorGrid.id);
		if (m_count[lastDigitsIP - 11]===0){
			m_width=data.length;
			m_specrumTimeSlices[lastDigitsIP - 11]=[];
			m_colorTimeSlices[lastDigitsIP - 11]=[];
			m_arrSpecrumTimeSlices[lastDigitsIP - 11]=[];
			empty = Array.apply(null, new Array(m_width)).map(Number.prototype.valueOf,0);
			//var emptyColor = Array.apply(null, new Array(m_width)).map(Number.prototype.valueOf,1);
			//m_specrumTimeSlices.push(data.join(" "));
			m_specrumTimeSlices[lastDigitsIP - 11].push(data.join(" "));
			m_colorTimeSlices[lastDigitsIP - 11].push(dataToColor(data, overlay).join(" "));
			m_arrSpecrumTimeSlices[lastDigitsIP - 11].push(data);
			
			for(var i=0; i<(m_slices); i++) {
				m_specrumTimeSlices[lastDigitsIP - 11].push(empty.join(" "));
				m_colorTimeSlices[lastDigitsIP - 11].push(dataToColor(empty, overlay).join(" "));
				m_arrSpecrumTimeSlices[lastDigitsIP - 11].push(empty);
			}
			
			m_count[lastDigitsIP - 11]=1;
		} else {
			for(var i=0;i<2;i++){
				m_specrumTimeSlices[lastDigitsIP - 11].pop();
				m_colorTimeSlices[lastDigitsIP - 11].pop();
				m_arrSpecrumTimeSlices[lastDigitsIP - 11].pop();
			}
			if(data.length>m_width){
				data=data.slice(0,m_width);
			}
			if(data.length<m_width){
				data.push(empty.slice(0, (m_width-data.length)));
			}
			
			/*
			if(data.indexOf(null)<-1){
				alert(data.indexOf(null));
			}*/
			m_specrumTimeSlices[lastDigitsIP - 11].unshift(data.join(" "));
			m_colorTimeSlices[lastDigitsIP - 11].unshift(dataToColor(data, overlay).join(" "));
			m_arrSpecrumTimeSlices[lastDigitsIP - 11].unshift(data);
		}
		empty = Array.apply(null, new Array(m_width)).map(Number.prototype.valueOf,0);
		m_specrumTimeSlices[lastDigitsIP - 11][m_slices] = empty.join(" ");
		m_colorTimeSlices[lastDigitsIP - 11][m_slices] = dataToColor(empty, overlay).join(" ");
		m_arrSpecrumTimeSlices[lastDigitsIP - 11][m_slices] = empty;
		//2D d3.js heatmap
		thisModule.redrawHeatmap(heatmapDiv, displacement_canvas, displacement_canvas_color, lastDigitsIP);

		var gridStr = m_specrumTimeSlices[lastDigitsIP - 11].join(" ");
		var colorStr = m_colorTimeSlices[lastDigitsIP - 11].join(" ");
                // commented by Ayat to hide the elevation
		/*colorGrid.color = colorStr; 
		elevGrid.setAttribute("xDimension", m_width);
		elevGrid.setAttribute("zDimension", m_slices+1);
		elevGrid.setAttribute("xspacing", 20.25/(m_width-1));
		elevGrid.setAttribute("zspacing", 6.81/(m_slices-1));
		elevGrid.setAttribute("height", gridStr);*/
		
		//alert(colorStr.split(' ').length + ' ' + gridStr.split(' ').length);
		
		//reload
		var container = elevGrid.parentNode;
		var content = container.innerHTML;
		container.innerHTML = content;// commented by Ayat to hide the elevation
	}
	
	function HSVtoRGB(h, s, v) {
	    var r, g, b, i, f, p, q, t;
	    if (h && s === undefined && v === undefined) {
	        s = h.s, v = h.v, h = h.h;
	    }
	    i = Math.floor(h * 6);
	    f = h * 6 - i;
	    p = v * (1 - s);
	    q = v * (1 - f * s);
	    t = v * (1 - (1 - f) * s);
	    switch (i % 6) {
	        case 0: r = v, g = t, b = p; break;
	        case 1: r = q, g = v, b = p; break;
	        case 2: r = p, g = v, b = t; break;
	        case 3: r = p, g = q, b = v; break;
	        case 4: r = t, g = p, b = v; break;
	        case 5: r = v, g = p, b = q; break;
	    }
	    return r + ' ' + g + ' ' + b;
	}

	function checkIfZeroes(data)
	{
		for (var i=0; i<data.length; i++) {
			if(data[i]!=0)
				return false;
		}
		return true;
	}
	
	function dataToColor(data, m_overlay){
		var colorArray=[];
		/*if(checkIfZeroes(data)){
			colorArray.push(1,0,0);
			return colorArray;
		}*/
		for (var i=0; i<data.length; i++) {
			var c=(240-(data[i]*240/m_maxval))/360;
			if (c<0){
				c=0;
			} else if (c>(2/3)){
				c=(2/3);
			}
			
			var low=m_overlay.selLow;
			var high=m_overlay.selHigh;
			
			low=Math.ceil(low*data.length);
			high=Math.floor(high*data.length);
						
			if(i>=low && i<=high) {
				colorArray.push(HSVtoRGB(5/6, 1, 1));
				//colorArray.push(HSVtoRGB(c, 0, 0));
			} else {
				colorArray.push(HSVtoRGB(c, 1, 1));
			}
			
		}
		return colorArray;
	}
	
	function fitToContainer(canvas){
		// Make it visually fill the positioned parent
                canvas.style.width ='100%';
		canvas.style.height='100%';
		// ...then set the internal size to match
		canvas.width  = canvas.offsetWidth;
		canvas.height = canvas.offsetHeight;
	}

	function makeGraph(canvasID, graphData, graphLabels) {
		var canvas = document.getElementById(canvasID);
		fitToContainer(canvas);

		var ctx = canvas.getContext("2d");
		ctx.clearRect(0, 0, canvas.width, canvas.height);
		ctx.globalAlpha = 0.5;
		ctx.fillStyle = "#C0C0C0";
		ctx.fillRect(0, 0, canvas.width, canvas.height);
		var line = new RGraph.Line(canvasID, graphData);
		line.Set('chart.labels', graphLabels);
		line.Set('chart.text.size', 7);
		line.Set('chart.colors', ['red']);
		line.Set('chart.linewidth', 3);
		//line.Set('chart.spline', !RGraph.isOld());
		line.Set('chart.scale.decimals', 1);
		//line.Set('chart.background.barcolor2', 'rgba(0,0,0,0.4)');
		line.Set('chart.background.barcolor1', 'rgba(0,0,0,0.3)');
		//line.Set('chart.filled', true);
		//line.Set('chart.fillstyle', 'rgba(0,0,0,0.5)');
		//line.Set('chart.shadow', true);
		line.Set('chart.hmargin', 0);
		line.Set('chart.gutter.left', leftGraphMargin);
		line.Set('chart.gutter.right', rightGraphMargin);
		line.Set('chart.title.yaxis.pos', 0.2);
		line.Set('chart.title.xaxis', "Frequency, MHz");
		line.Set('chart.gutter.bottom', 50);
		line.Set('xaxispos', 'center');
		line.Set('chart.title.yaxis', "Energy");
		line.Set('chart.numyticks', 4);
		line.Set('chart.ylabels.count', 2);
		line.Draw();
	}


	thisModule.rand=false;
	
	thisModule.redrawHeatmap = function  (heatmapDiv, displacement_canvas, displacement_canvas_color, lastDigitsIP) {
		var width = $('#'+heatmapDiv).width(),
		    height = $('#'+heatmapDiv).height();

		var data = m_arrSpecrumTimeSlices[lastDigitsIP - 11]; // Ayat the parameter to the following self invoking function so heatmap = data
		// Ayat alert(data[0][0]+", length "+ data[0].length);
		(function(heatmap) {
		  var dx = heatmap[0].length, // Ayat 256
		      dy = heatmap.length; //Ayat 11

		  var x = d3.scale.linear()
		      .domain([/*thisModule.lowBound_*/thisModule.lowBound_, highBound_])
		      .range([0, width]);

		  var y = d3.scale.linear()
		      .domain([0, dy])
		      .range([height, 0]);

		  var color = d3.scale.linear()
		      .domain([0, 4*m_maxval/4])// 2*m_maxval/4, 3*m_maxval/4, 4*m_maxval/4])
		      .range(["black", "white"]);//["blue", 'cyan', "green", 'yellow', "red"]);

		  var xAxis = d3.svg.axis()
		      .scale(x)
		      .orient("top")
                      .ticks(width/100);
		  /* var yAxis = d3.svg.axis()
						  .scale(y)
						  .orient("right")
						  .ticks(height/50);
		  */
                 //alert(displacement_canvas);
                    var Ayat_canvas = document.getElementById(displacement_canvas);
                    var Ayat_canvas_color = document.getElementById(displacement_canvas_color);
                    var Ayat_context_heights = Ayat_canvas.getContext("2d");
                    var Ayat_context = Ayat_canvas_color.getContext("2d");
                 // alert(Ayat_canvas_color + " " + Ayat_canvas);
		    Ayat_canvas.width = 256;
                    Ayat_canvas.height = 256;
                    Ayat_canvas_color.width = 256;
                    Ayat_canvas_color.height = 256;
		    //Ayat_drawImage_dis(Ayat_canvas);
                   // Ayat_drawImage(Ayat_canvas_color);
                   
		  var heatmapArea=document.getElementById(heatmapDiv);
		 // alert(heatmapDiv);
		  heatmapArea.innerHTML='';
		  var heatmap_canvas = d3.select(heatmapArea).append("canvas")//Ayat heatmap canvas 
		    .attr("width", dx)
		    .attr("height", dy)
		  //.attr('id', 'heatCanv')
		    .style("width", width + "px")
		    .style("height", height + "px")
		    .call(drawImage);
                    Ayat_context.drawImage(heatmap_canvas.node(), 0, 0, 256, 256);
                    Ayat_context_heights.drawImage(heatmap_canvas.node(), 0, 0, 256, 256);
                    Ayat_canvas_color.parentNode._x3domNode.fieldChanged("url");
                    Ayat_canvas.parentNode.parentNode.parentNode.parentNode.parentNode._x3domNode._dirty.texture = true;
                    document.getElementById("spectrum_vis_x3d").render();
		
		  var svg = d3.select(heatmapArea).append("svg")
		     .attr("width", width)
		     .attr("height", height);

		  svg.append("g")
		     .attr("class", "x axis")
		     .attr("transform", "translate(0," + height + ")")
		     .call(xAxis)
		     .call(removeZero);
		
		  //add Legend
                  if (width>400 && height>200){
			var svgWidth = width,
			svgHeight = height,
			x1 = width-250,
			barWidth = 200,
			y1 = height-90,
			barHeight = 50,
			numberHues = 10;
			var idGradient = "legendGradient";
			 
			var svgForLegendStuff = d3.select(heatmapArea).append("svg")
			.attr("width", svgWidth)
			.attr("height", svgHeight);
			 
			//create the empty gradient that we're going to populate later
			svgForLegendStuff.append("g")
			.append("defs")
			.append("linearGradient")
			.attr("id",idGradient)
			.attr("x1","0%")
			.attr("x2","100%")
			.attr("y1","0%")
			.attr("y2","0%"); // x1=0, x2=100%, y1=y2 results in a horizontal gradient
			// it would have been vertical if x1=x2, y1=0, y2=100%
			// See
			// http://www.w3.org/TR/SVG/pservers.html#LinearGradients
			// for more details and fancier things you can do
			//create the bar for the legend to go into
			// the "fill" attribute hooks the gradient up to this rect
			svgForLegendStuff.append("rect")
			.attr("fill","url(#" + idGradient + ")")
			.attr("x",x1)
			.attr("y",y1)
			.attr("width",barWidth)
			.attr("height",barHeight)
			.attr("rx",20) //rounded corners, of course!
			.attr("ry",20)
			.attr("stroke-width",2)
			.attr("stroke",'white');
			 
			//add text on either side of the bar
			 
			var textY = y1 + barHeight/2 + 15;
			svgForLegendStuff.append("text")
			.attr("class","legendText")
			.attr("text-anchor", "middle")
			.attr("x",x1 - 10)
			.attr("y",textY-5)
			.attr("dy",0)
			.text("0");
			 
			svgForLegendStuff.append("text")
			.attr("class","legendText")
			.attr("text-anchor", "left")
			.attr("x",x1 + barWidth + 5)
			.attr("y",textY-5)
			.attr("dy",0)
			.text(numberHues);


			svgForLegendStuff.append("text")
			.attr("class","legendText")
			.attr("text-anchor", "left")
			.attr("x",(width-barWidth)/2)
			.attr("y",height-30)
			.attr("dy",0)
			.text("Frequency, MHz");
			 
			 
			//we go from a somewhat transparent blue/green (hue = 160�, opacity = 0.3) to a fully opaque reddish (hue = 0�, opacity = 1)
			var hueStart = 240, hueEnd = 0;
			var opacityStart = 1, opacityEnd = 1.0;
			var theHue, rgbString, opacity,p;
			 
			var deltaPercent = 1/(numberHues-1);
			var deltaHue = (hueEnd - hueStart)/(numberHues - 1);
			var deltaOpacity = (opacityEnd - opacityStart)/(numberHues - 1);
			 
			//kind of out of order, but set up the data here
			var theData = [];
			for (var i=0;i < numberHues;i++) {
			theHue = hueStart + deltaHue*i;
			//the second parameter, set to 1 here, is the saturation
			// the third parameter is "lightness"
			rgbString = d3.hsl(theHue,1,0.6).toString();
			opacity = opacityStart + deltaOpacity*i;
			p = 0 + deltaPercent*i;
			//console.log("i, values: " + i + ", " + rgbString + ", " + opacity + ", " + p);
			theData.push({"rgb":rgbString, "opacity":opacity, "percent":p});
			}
			 
			//now the d3 magic (imo) ...
			var stops = d3.select('#' + idGradient).selectAll('stop')
			.data(theData);
			stops.enter().append('stop');
			stops.attr('offset',function(d) {
			return d.percent;
			})
			.attr('stop-color',function(d) {
			return d.rgb;
			})
			.attr('stop-opacity',function(d) {
			return d.opacity;
			});

		  }// end if Ayat


		  // Compute the pixel colors; scaled by CSS.
		  function drawImage(canvas) {
		    var context = canvas.node().getContext("2d"),
		        image = context.createImageData(dx, dy);
                    for (var y = 0, p = -1; y < dy; ++y) {
		      for (var x = 0; x < dx; ++x) {
		        var c = d3.rgb(color(heatmap[y][x])); // Ayat map data values to rgb color
		        image.data[++p] = c.r;
		        image.data[++p] = c.g;
		        image.data[++p] = c.b;
		        image.data[++p] = 255;				
		      }
		    }
			context.putImageData(image, 0, 0);
                 }
		  /////////////////////Ayat///////////////
                  function Ayat_drawImage(canvas) {
		    var context = canvas.getContext("2d"),
		        image = context.createImageData(dx, dx);
                        
                   for (var z = 0, p = -1; z < 32; ++z) {
                    for (var y = 0; y < 8; ++y) {
                       
		     for (var x = 0; x < dx; ++x) {
                        var c = d3.rgb(color(heatmap[y][x])); // Ayat map data values to rgb color
                        image.data[++p] = c.r;
                        image.data[++p] = c.g;
                        image.data[++p] = c.b;
                        image.data[++p] = 255;
                        }
                         // alert(dx);
		    }
                 }
			/*for (var y = 0, p = -1; y < dy; ++y) {
		      for (var x = 0; x < dx; ++x) {
                          alert(image.data[++p]);
                        }
                      }*/
                      //alert(p);
                      context.putImageData(image, 0, 0);
                       //alert(canvas.width + " "+ canvas.height+" "+image.data.length); 
			
		  }
                  function Ayat_drawImage_dis(canvas) {
		    var context = canvas.getContext("2d"),
		        image = context.createImageData(dx, dx);
                        
                   for (var z = 0, p = -1; z < 32; ++z) {
                    for (var y = 0; y < 8; ++y) {
                       
		     for (var x = 0; x < dx; ++x) {
                       // var c = d3.rgb(color(heatmap[y][x])); // Ayat map data values to rgb color
                        image.data[++p] = heatmap[y][x];
                        image.data[++p] = 0;
                        image.data[++p] = 0;
                        image.data[++p] = 255;
                        }
                         // alert(dx);
		    }
                 }
			/*for (var y = 0, p = -1; y < dy; ++y) {
		      for (var x = 0; x < dx; ++x) {
                          alert(image.data[++p]);
                        }
                      }*/
                      //alert(p);
                      context.putImageData(image, 0, 0);
                       //alert(canvas.width + " "+ canvas.height+" "+image.data.length); 
			
		  }
			///////////////////////////////////////
		  function removeZero(axis) {
		    axis.selectAll("g").filter(function(d) { return !d; }).remove();
		  }
		})(data);
	};// semicolone added by Aayt

	////////////////////////////////////////
	// WEB SOCKET COMPUTATIONS
	///////////////////////////////////////

	thisModule.initialize1 = function (lastDigitsIP, nTimeSlices, gridID, gridColorID, heatmapDivID, linegraphID, canvas, displacement_canvas, displacement_canvas_color, show_floors, showStatus, transParams) {
		thisModule.init(lastDigitsIP, nTimeSlices, gridID, gridColorID, heatmapDivID, linegraphID, canvas, displacement_canvas, displacement_canvas_color, show_floors, showStatus, transParams);
	};// semicolone added by Aayt
	
	thisModule.initialize2 = function (lastDigitsIP, nTimeSlices, gridID, gridColorID, heatmapDivID, linegraphID, canvas, displacement_canvas, displacement_canvas_color, show_floors, showStatus, transParams) {
		thisModule.init(lastDigitsIP, nTimeSlices, gridID, gridColorID, heatmapDivID, linegraphID, canvas, displacement_canvas, displacement_canvas_color, show_floors, showStatus, transParams);
	};// semicolone added by Aayt
	
	thisModule.initialize3 = function (lastDigitsIP, nTimeSlices, gridID, gridColorID, heatmapDivID, linegraphID, canvas, displacement_canvas, show_floors, showStatus, transParams) {
		thisModule.init(lastDigitsIP, nTimeSlices, gridID, gridColorID, heatmapDivID, linegraphID, canvas, displacement_canvas, displacement_canvas_color, show_floors, showStatus, transParams);
	};// semicolone added by Aayt
	
	thisModule.initialize4 = function (lastDigitsIP, nTimeSlices, gridID, gridColorID, heatmapDivID, linegraphID, canvas, displacement_canvas, displacement_canvas_color, show_floors, showStatus, transParams) {
		thisModule.init(lastDigitsIP, nTimeSlices, gridID, gridColorID, heatmapDivID, linegraphID, canvas, displacement_canvas, displacement_canvas_color, show_floors, showStatus, transParams);
	};// semicolone added by Aayt
	
	thisModule.initialize5 = function (lastDigitsIP, nTimeSlices, gridID, gridColorID, heatmapDivID, linegraphID, canvas, displacement_canvas, displacement_canvas_color, show_floors, showStatus, transParams) {
		thisModule.init(lastDigitsIP, nTimeSlices, gridID, gridColorID, heatmapDivID, linegraphID, canvas, displacement_canvas, displacement_canvas_color, show_floors, showStatus, transParams);
	};// semicolone added by Aayt
	
	thisModule.initialize6 = function (lastDigitsIP, nTimeSlices, gridID, gridColorID, heatmapDivID, linegraphID, canvas, displacement_canvas, displacement_canvas_color, show_floors, showStatus, transParams) {
		thisModule.init(lastDigitsIP, nTimeSlices, gridID, gridColorID, heatmapDivID, linegraphID, canvas, displacement_canvas, displacement_canvas_color, show_floors, showStatus, transParams);
	};// semicolone added by Aayt
	
	thisModule.initialize7 = function (lastDigitsIP, nTimeSlices, gridID, gridColorID, heatmapDivID, linegraphID, canvas, displacement_canvas, displacement_canvas_color, show_floors, showStatus, transParams) {
		thisModule.init(lastDigitsIP, nTimeSlices, gridID, gridColorID, heatmapDivID, linegraphID, canvas, displacement_canvas, displacement_canvas_color, show_floors, showStatus, transParams);
	};// semicolone added by Aayt
	
	thisModule.initialize8 = function (lastDigitsIP, nTimeSlices, gridID, gridColorID, heatmapDivID, linegraphID, canvas, displacement_canvas, displacement_canvas_color, show_floors, showStatus, transParams) {
		thisModule.init(lastDigitsIP, nTimeSlices, gridID, gridColorID, heatmapDivID, linegraphID, canvas, displacement_canvas, displacement_canvas_color, show_floors, showStatus, transParams);
	};// semicolone added by Aayt
	
	thisModule.initialize9 = function (lastDigitsIP, nTimeSlices, gridID, gridColorID, heatmapDivID, linegraphID, canvas, displacement_canvas, displacement_canvas_color, show_floors, showStatus, transParams) {
		thisModule.init(lastDigitsIP, nTimeSlices, gridID, gridColorID, heatmapDivID, linegraphID, canvas, displacement_canvas, displacement_canvas_color, show_floors, showStatus, transParams);
	};// semicolone added by Aayt
	
	thisModule.initialize10 = function (lastDigitsIP, nTimeSlices, gridID, gridColorID, heatmapDivID, linegraphID, canvas, displacement_canvas, displacement_canvas_color, show_floors, showStatus, transParams) {
		thisModule.init(lastDigitsIP, nTimeSlices, gridID, gridColorID, heatmapDivID, linegraphID, canvas, displacement_canvas, displacement_canvas_color, show_floors, showStatus, transParams);
	};// semicolone added by Aayt
	
	thisModule.initialize11 = function (lastDigitsIP, nTimeSlices, gridID, gridColorID, heatmapDivID, linegraphID, canvas, displacement_canvas, displacement_canvas_color, show_floors, showStatus, transParams) {
		thisModule.init(lastDigitsIP, nTimeSlices, gridID, gridColorID, heatmapDivID, linegraphID, canvas, displacement_canvas,displacement_canvas_color, show_floors, showStatus, transParams);
	};// semicolone added by Aayt
	
	thisModule.initialize12 = function (lastDigitsIP, nTimeSlices, gridID, gridColorID, heatmapDivID, linegraphID, canvas, displacement_canvas, displacement_canvas_color, show_floors, showStatus, transParams) {
		thisModule.init(lastDigitsIP, nTimeSlices, gridID, gridColorID, heatmapDivID, linegraphID, canvas, displacement_canvas, displacement_canvas_color, show_floors, showStatus, transParams);
	};// semicolone added by Aayt
	
	thisModule.initialize13 = function (lastDigitsIP, nTimeSlices, gridID, gridColorID, heatmapDivID, linegraphID, canvas, displacement_canvas, displacement_canvas_color, show_floors, showStatus, transParams) {
		thisModule.init(lastDigitsIP, nTimeSlices, gridID, gridColorID, heatmapDivID, linegraphID, canvas, displacement_canvas, displacement_canvas_color, show_floors, showStatus, transParams);
	};// semicolone added by Aayt
	
	thisModule.initialize14 = function (lastDigitsIP, nTimeSlices, gridID, gridColorID, heatmapDivID, linegraphID, canvas, displacement_canvas, displacement_canvas_color, show_floors, showStatus, transParams) {
		thisModule.init(lastDigitsIP, nTimeSlices, gridID, gridColorID, heatmapDivID, linegraphID, canvas, displacement_canvas, displacement_canvas_color, show_floors, showStatus, transParams);
	};// semicolone added by Aayt
	
	thisModule.init = function (lastDigitsIP, nTimeSlices, gridID, gridColorID, heatmapDivID, linegraphID, canvas, displacement_canvas, displacement_canvas_color, show_floors, showStatus, transParams) {
		m_slices=nTimeSlices;
		m_count[lastDigitsIP - 11]=0;
		m_showStatus=showStatus;
		
		//WebSockets
		connectedNodes.push(lastDigitsIP - 11);
		thisModule.connected = true;
		var prevTime = 0; // there were no "var" Ayat Added it
		period = (800/transParams.r);
		
		centerF_ = transParams.f/1000000.0;
		thisModule.bandwidth_ = transParams.b/1000000.0;
		thisModule.lowBound_ = centerF_ - thisModule.bandwidth_ / 2;
		thisModule.highBound_ = centerF_ + thisModule.bandwidth_ / 2;
		
		console.log(centerF_);
		console.log(thisModule.bandwidth_);
		console.log(thisModule.lowBound_);
		console.log(thisModule.highBound_);
		
		socket[lastDigitsIP - 11] = io.connect('128.173.221.40:8888', {'force new connection': true});
		socket[lastDigitsIP - 11].on('time', function(data) {
			var overlay_n = selOverlay(document.getElementById(linegraphID), leftGraphMargin, rightGraphMargin);
			if(thisModule.connected) {
                               // var obj = JSON.parse(data);
				processResponse(JSON.parse(data), gridID, gridColorID, heatmapDivID, linegraphID, overlay_n, canvas, displacement_canvas, displacement_canvas_color, lastDigitsIP);
				prevTime = new Date().getTime();
			}
		});
		
                socket[lastDigitsIP - 11].on('users_rsp', function(data) {
                    alert(data.toString());
                });
                socket[lastDigitsIP - 11].on('error', function(error) { console.error(error); });
                var initParams={};
                initParams.transParams=transParams;
                initParams.nodeID=lastDigitsIP;
                socket[lastDigitsIP - 11].emit('nodeID', initParams);
                thisModule.connected = true;
                convertToMHz(transParams);
                console.log(JSON.stringify(transParams));
	};// semicolone added by Aayt

	thisModule.fit = function () {
		fitToContainer(document.getElementById('layer2'));
		//Ayat
		//fitToContainer(document.getElementById('dis_canvas'));
	};// semicolone added by Aayt
	thisModule.connected=false;

	thisModule.disconnect = function (lastDigitsIP) {
		socket[lastDigitsIP - 11].emit ('closeSSH', lastDigitsIP);
		m_specrumTimeSlices[lastDigitsIP - 11] = [];
		m_colorTimeSlices[lastDigitsIP - 11] = [];
		m_arrSpecrumTimeSlices[lastDigitsIP - 11] = [];
		elevGrid=document.getElementById("specGrid_" + lastDigitsIP);
		document.getElementById("heatmapArea"+lastDigitsIP).innerHTML = '';
		document.getElementById("cvs" + lastDigitsIP).innerHTML = '';
		//elevGrid.innerHTML = '<color id="specGridColor" color="0 0 0 0 0 0 0 0 0 0 0 0"></color>';
		elevGrid.height="0.0 0.0 0.0 0.0";
		elevGrid.solid="false";
		elevGrid.xdimension = "2";
		elevGrid.zdimension = "2";
		elevGrid.xspacing = "20.25";
		elevGrid.zspacing = "6.81";
	};// semicolone added by Aayt

	function convertToMHz(transParams){
		centerF_ = transParams.f / 1000000;
		thisModule.bandwidth_ = transParams.b / 1000000;
		thisModule.lowBound_ = centerF_ - thisModule.bandwidth_ / 2;
		highBound_ = centerF_ + thisModule.bandwidth_ / 2;
	}

	thisModule.updateParams =  function(transParams, lastDigitsIP) {
		if (thisModule.connected) {
			thisModule.connected = true;
		    var initParams={};
            initParams.transParams=transParams;
            initParams.nodeID=lastDigitsIP;
			m_count[lastDigitsIP - 11]=0;
			console.log("UPDATED PARAMS");
			period = 800/transParams.r;
			socket[lastDigitsIP - 11].emit('nodeID', initParams);
		}
		console.log(JSON.stringify(transParams));
		convertToMHz(transParams);
	}
	
	thisModule.updateTimeSlices = function(time_slices) {
		m_slices = time_slices;
	}

	thisModule.displayUsers =  function(transParams) {
		socket[0].emit ('users_req');
	}

	thisModule.setParamsCRTS = function (paramsCRTS) {
		socket[0].emit('getSettingsCRTS', paramsCRTS);
	}

	thisModule.stopCTRS = function () {
		socket[0].emit('stopCRTS');
	}

	return thisModule;
}());
/*
var spectrum = [];
for(var i=0;i<48;i++) {
	spectrum[i] = spectr;
}*/